import React from "react";
import ReactDOM from "react-dom";
import AnxietyQuiz from "./Data/AnxietyQuiz"
import DepressionQuiz from "./Data/DepressionQuiz";

import "./App.css"

const App = () => {
  return (
    <div>
      <AnxietyQuiz />
    </div>
  );
};

ReactDOM.render(<App />, document.getElementById("root"));
export default App