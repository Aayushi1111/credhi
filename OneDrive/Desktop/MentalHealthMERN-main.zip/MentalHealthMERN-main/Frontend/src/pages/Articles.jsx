const Articles = () => {
  return (
    <>
      <h2>Add important articles links here to answer FAQs and make people aware about the topic.</h2>
    </>
  );
};

export default Articles;
