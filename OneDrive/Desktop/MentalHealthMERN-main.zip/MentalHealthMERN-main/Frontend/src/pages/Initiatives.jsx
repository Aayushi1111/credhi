const Initiatives = () => {
  return <h2>All initiatives and workshops.</h2>;
};

export default Initiatives;
