import React from 'react';

import SupportGroups from './SupportGroups';
import SupportGroups2 from './SupportGroups2';

const SupportGroupsMain = () => {
  return (
    <div className="main-page">
      <SupportGroups />
      <SupportGroups2 />
    </div>
  );
};

export default SupportGroupsMain;