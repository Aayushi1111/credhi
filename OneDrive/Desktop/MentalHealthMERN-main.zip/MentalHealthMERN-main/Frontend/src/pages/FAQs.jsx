const FAQs = () => {
  return <h2>FAQS</h2>;
};

export default FAQs;
