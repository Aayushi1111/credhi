const Volunteer = () => {
    return <h2>Volunteer for Us.</h2>;
  };
  
export default Volunteer;
  