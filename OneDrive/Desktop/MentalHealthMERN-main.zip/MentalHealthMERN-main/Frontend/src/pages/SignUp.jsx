const SignUp = () => {
  return <h2>Sign Up / Register</h2>;
};

export default SignUp;
