const Help = () => {
  return <h2>Helplines + Find Doctors related to mental heah</h2>;
};

export default Help;
